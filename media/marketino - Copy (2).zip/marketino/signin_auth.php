<?php 
    session_start();
    ob_start();
    if(isset($_POST['submit']))
    {
        include 'includes/conn.php';
        $email = $_POST['email'];
        $sql = "SELECT * FROM admin WHERE email = '$email'";
        $query = mysqli_query($conn, $sql);
        if(mysqli_num_rows($query) > 0) 
        {
            $row = mysqli_fetch_assoc($query);
            $id = $row['userid'];
            $password = $row['password'];
            $password = str_replace("$2a$","$2y$",$password);
            if(isset($_POST['password']))
            {
                if(password_verify($_POST['password'], $password))
                {
                    $_SESSION['message'] = 'Successfully Logged in';
                    echo 'success';
                    $_SESSION['email'] = $email;
                    $_SESSION['adminid'] = $id;
                    echo "success";
                    header('Location: admin/index.php');
                }
                else {
                    $_SESSION['error'] = 'Password is Wrong';
                    header('Location: signin.php');
                }
            }
            else {
                $_SESSION['error'] = 'Password not given';
                header('Location: signin.php');
            }
        }
        elseif(mysqli_num_rows($query) == 0) {
            $sql = "SELECT * FROM staffs WHERE email = '$email'";
            $query = mysqli_query($conn, $sql);
            if(mysqli_num_rows($query) > 0) 
            {
                $row = mysqli_fetch_assoc($query);
                $id = $row['id'];
                $password = $row['password'];
                $password = str_replace('$2a$','$2y$',$password);
                if(isset($_POST['password']))
                {
                    echo $password;
                    if(password_verify($_POST['password'], $password))
                    {
                        $_SESSION['message'] = 'Successfully Logged in';
                        echo 'success';
                        $_SESSION['email'] = $email;
                        $_SESSION['userid'] = $id;
                        header('Location: index.php');
                    }
                    else {
                        $_SESSION['error'] = "Password is wrong";
                        header('Location: signin.php');
                    }
                }
                else {
                    $_SESSION['error'] = 'Password is Wrong';
                    header('Location: signin.php');
                }
            }
            else {
                $_SESSION['error'] = 'Email not registered';
                header('Location: signin.php');
            }
        }
        else 
        {
            $_SESSION['error'] = 'Email is not registered';
            header('Location: signin.php');
        }
    }
    else 
    {
        $_SESSION['error'] = 'Unauthorized Email';
        header('Location: signin.php');
    }
?>