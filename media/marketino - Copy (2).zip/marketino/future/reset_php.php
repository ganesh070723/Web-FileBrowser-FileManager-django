<?php
session_start();
ob_start();
if($_SERVER['REQUEST_METHOD'] == "POST")
{
    include './conn.php';
    if(isset($_POST['email']))
    {
        $email = $_POST['email'];
        $sql = "SELECT * FROM admin WHERE email = '$email'";
        $query = mysqli_query($conn, $sql);

        if(mysqli_num_rows($query) > 0) 
        {
            $_SESSION['reset_email'] = $email;
            $_SESSION['vcode'] = '12345';
            $_SESSION['success'] = 'Verification code has been sent to your mail';
            $sql = "UPDATE users SET vcode = '12345' WHERE email = '$email'";
            mysqli_query($conn, $sql);
            header("Location: new-password.php");
        }
        else
        {
            $_SESSION['error'] = 'email was wrong';
            header("Location: reset-password.php");
        }
    }
} 
?>