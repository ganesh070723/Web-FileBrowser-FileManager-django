<?php
session_start();
ob_start();
if($_SERVER['REQUEST_METHOD'] == "POST")
{
    include './conn.php';
    if(isset($_POST['vcode']))
    {
        $vcode = $_POST['vcode'];
        $email = $_SESSION['reset_email'];
        $password = $_POST['password'];
        $cnpass = $_POST['confirm-password'];
        if($password == $cnpass)
        {
        $sql = "SELECT * FROM admin WHERE email = '$email'";
        $query = mysqli_query($conn, $sql);

        if(mysqli_num_rows($query) > 0) 
        {
            $row = mysqli_fetch_assoc($query);
            if($row['vcode'] == $vcode)
            {
                $_SESSION['success'] = 'Password reset successfully';
                $opts04 = [ "cost" => 10];
                $hashp04 = password_hash($password, PASSWORD_BCRYPT, $opts04);
                mysqli_query($conn,"UPDATE users SET password='".$hashp04."' WHERE email='".$_SESSION['reset_email']."'");
                header('Location: ../signin.php');
            }
            else 
            {
                $_SESSION['error'] = 'Verification code is not matching';
                header('Location: new-password.php');   
            }
            // $_SESSION['reset_email'] = $email;
            // $_SESSION['vcode'] = '12345';
            // $_SESSION['success'] = 'Verification code has been sent to your mail';
            // $sql = "UPDATE users SET vcode = '12345' WHERE email = '$email'";
            // mysqli_query($conn, $sql);
            // header("Location: new-password.php");
        }
        else
        {
            $_SESSION['error'] = 'email was wrong';
            header("Location: reset-password.php");
        }
    }
    else 
    {
        $_SESSION['error'] = 'Password not matching';
        header('Location: new-password.php');
    }
}
} 
?>